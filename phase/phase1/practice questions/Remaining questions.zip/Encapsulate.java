package com.java.training;

public class Encapsulate {

}
